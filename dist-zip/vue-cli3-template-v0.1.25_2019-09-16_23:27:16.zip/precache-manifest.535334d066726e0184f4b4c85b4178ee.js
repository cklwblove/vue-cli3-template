self.__precacheManifest = [
  {
    "revision": "684324341641057edcc0249b6eb21001",
    "url": "static/img/dog.68432434.svg"
  },
  {
    "revision": "0dd17aa313640e005baf",
    "url": "static/css/app.3d5de184.css"
  },
  {
    "revision": "3fd28f32e9fc7c458039",
    "url": "static/css/chunk-595fb0d3.a4df6479.css"
  },
  {
    "revision": "3fd28f32e9fc7c458039",
    "url": "static/js/chunk-595fb0d3.277fdbad.js"
  },
  {
    "revision": "570c62834ad6290a9a93",
    "url": "static/css/chunk-d869a556.a9dfa17b.css"
  },
  {
    "revision": "570c62834ad6290a9a93",
    "url": "static/js/chunk-d869a556.897a300a.js"
  },
  {
    "revision": "4f16f5b0f67b57bb5ab3",
    "url": "static/js/chunk-vendors.d2426f6e.js"
  },
  {
    "revision": "5fb46fa2f5bf8c4ca34a",
    "url": "static/js/runtime.049cd1cc.js"
  },
  {
    "revision": "0dd17aa313640e005baf",
    "url": "static/js/app.0c8b41a3.js"
  },
  {
    "revision": "25ef99c181d75380ace36f5f6eca8090",
    "url": "static/img/cat.25ef99c1.svg"
  },
  {
    "revision": "0a825859c419a2dde809e52d91db863e",
    "url": "static/img/refresh.0a825859.svg"
  },
  {
    "revision": "7683a6ee05c3817101a0f38d493de90a",
    "url": "static/img/iconfont.7683a6ee.svg"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  },
  {
    "revision": "6ec43edf4f6747a8634cdc42f7169ffd",
    "url": "index.html"
  },
  {
    "revision": "3b610f7455e7309536ba67d6efd478d7",
    "url": "dll/js/vendor.dll.00bf1dd6.js"
  },
  {
    "revision": "d0d17d1edd6954a6db7b3b5782bb4ab5",
    "url": "config.local.js"
  }
];