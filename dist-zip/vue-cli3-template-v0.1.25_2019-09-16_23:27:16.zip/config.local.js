window.LOCAL_CONFIG = {
  API_HOME: 'https://api.github.com/'
}
